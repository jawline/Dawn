#ifndef _STDIO_DEF_H_
#define _STDIO_DEF_H_
#define NULL 0
#include "printf.h"
#include "va_list.h"

#endif
