#ifndef _HEAP_DEF_H_
#define _HEAP_DEF_H_
#include "headers/int_types.h"
#include "ordered_array.h"

#define HEAP_MAGIC 0x959AB
#define HEAP_MIN_SIZE     0x70000

//hent stands for Heap entry

typedef struct {
	uint32 magic;
	uint8 hole;
	uint32 size;
} hent_header_t;

typedef struct {
	uint32 magic;
	hent_header_t * header; //Pointer back to the header. 
} hent_footer_t;

typedef struct
{
   ordered_array_t index;
   uint32 start_address; // The start of our allocated space.
   uint32 end_address;   // The end of our allocated space. May be expanded up to max_address.
   uint32 max_address;   // The maximum address the heap can be expanded to.
   uint8 supervisor;     // Should extra pages requested by us be mapped as supervisor-only?
   uint8 readonly;       // Should extra pages requested by us be mapped as read-only?
} heap_t;


/**
  Allocates a contiguous region of memory 'size' in size. If page_align==1, it creates that block starting
  on a page boundary.
**/

void *heap_alloc(uint32 size, uint8 page_align, heap_t *heap);

/**
  Releases a block allocated with 'alloc'.
**/
void heap_free(void *p, heap_t *heap);

#endif
