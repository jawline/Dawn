#include "kernel_heap.h"

heap_t * kernel_heap;

static int8 hent_header_t_less_than(void*a, void *b)
{
   return (((hent_header_t*)a)->size < ((hent_header_t*)b)->size)?1:0;
}

heap_t * create_kernel_heap(uint32 start, uint32 end_addr, uint32 max, uint8 supervisor, uint8 readonly)
{
   heap_t *heap = (heap_t*)placement_alloc(sizeof(heap_t), 0, 0);

   // All our assumptions are made on startAddress and endAddress being page-aligned.
   ASSERT(start%0x1000 == 0);
   ASSERT(end_addr%0x1000 == 0);

   // Initialise the index.
   heap->index = place_ordered_array( (void*)start, KHEAP_INDEX_SIZE, &hent_header_t_less_than);

   // Shift the start address forward to resemble where we can start putting data.
   start += sizeof(type_t)*KHEAP_INDEX_SIZE;

   // Make sure the start address is page-aligned.
   if (start & 0xFFFFF000 != 0)
   {
       start &= 0xFFFFF000;
       start += 0x1000;
   }
   // Write the start, end and max addresses into the heap structure.
   heap->start_address = start;
   heap->end_address = end_addr;
   heap->max_address = max;
   heap->supervisor = supervisor;
   heap->readonly = readonly;

   // We start off with one large hole in the index.
   hent_header_t *hole = (hent_header_t *)start;
   hole->size = end_addr-start;
   hole->magic = HEAP_MAGIC;
   hole->hole = 1;
   insert_ordered_array((void*)hole, &heap->index);

   return heap;
}
