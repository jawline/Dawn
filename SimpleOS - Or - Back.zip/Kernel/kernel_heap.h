#ifndef _KERNEL_HEAP_DEF_H_
#define _KERNEL_HEAP_DEF_H_
#include "heap.h"
#define KHEAP_START         0xC0000000
#define KHEAP_INITIAL_SIZE  0x100000
#define KHEAP_INDEX_SIZE 0x20000

heap_t *create_kernel_heap(uint32 start, uint32 end, uint32 max, uint8 supervisor, uint8 readonly);

#endif
