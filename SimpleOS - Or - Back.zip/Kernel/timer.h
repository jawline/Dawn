#ifndef TIMER_H
#define TIMER_H

#include "common.h"
#include "interrupt_handler.h"

void init_timer(uint32 frequency);

#endif
