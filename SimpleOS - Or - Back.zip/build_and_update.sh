#!/bin/sh

sh build_kernel.sh
sh update_image.sh
