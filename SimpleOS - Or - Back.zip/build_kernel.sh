#!/bin/sh

echo "Moving to Kernel Directory"
cd Kernel

echo "Building Kernel"
make
echo "Done!"
