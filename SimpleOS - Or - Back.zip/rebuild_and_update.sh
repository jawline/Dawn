#!/bin/sh

sh rebuild_kernel.sh
sh update_image.sh
