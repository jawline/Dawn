#ifndef _SYSTEM_TIME_DEF_H_
#define _SYSTEM_TIME_DEF_H_
#include "cmos_time.h"
#include "headers/int_types.h"

void Init_SysTime();

#endif
